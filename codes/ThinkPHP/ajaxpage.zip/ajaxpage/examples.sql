/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50520
Source Host           : localhost:3306
Source Database       : examples

Target Server Type    : MYSQL
Target Server Version : 50520
File Encoding         : 65001

Date: 2012-10-26 08:15:42
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `think_form`
-- ----------------------------
DROP TABLE IF EXISTS `think_form`;
CREATE TABLE `think_form` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of think_form
-- ----------------------------
INSERT INTO `think_form` VALUES ('1', 'text1', 'text1', '1351094268');
INSERT INTO `think_form` VALUES ('2', 'text2', 'text2', '1351094274');
INSERT INTO `think_form` VALUES ('3', 'text3', 'text3', '1351094281');
INSERT INTO `think_form` VALUES ('4', 'text4', 'text4', '1351094288');
INSERT INTO `think_form` VALUES ('5', 'text5', 'text5', '1351094295');
INSERT INTO `think_form` VALUES ('6', 'text6', 'text6', '1351094303');
INSERT INTO `think_form` VALUES ('7', 'text7', 'text7', '1351094311');
INSERT INTO `think_form` VALUES ('8', 'text8', 'text8', '1351094319');
INSERT INTO `think_form` VALUES ('9', 'text9', 'text9', '1351094332');
INSERT INTO `think_form` VALUES ('10', 'text10', 'text10', '1351094339');
INSERT INTO `think_form` VALUES ('11', 'test11', '11', '1351175331');
INSERT INTO `think_form` VALUES ('12', 'test12', '12', '1351175337');
INSERT INTO `think_form` VALUES ('13', 'test13', '12', '1351175343');
INSERT INTO `think_form` VALUES ('14', 'test14', '14', '1351175353');
INSERT INTO `think_form` VALUES ('15', 'test15', '15', '1351175360');
