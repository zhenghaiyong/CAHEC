<?php  
/**
 * CAHEC VRL ISM 简体中文语言包
 * @author   zhenghaiyong <zhenghaiyong@gmail.com>
 */
return array(
    // index.html
	'_DATA_LIST_' => '数据列表',
	'_GROUP_NAME_' => '组名',
	'_ID_' => '编号',
	'_TITLE_' => '标题',
	'_PUBLISH_TIME_' => '发表时间',
	'_STATUS_' => '状态',
	// add.html
	'_ADD_DATA_' => '添加数据',
	'_ADD_TITLE_' => '标题：',
	'_ADD_CONTENT_' => '内容：',
	// edit.html
	'_EDIT_DATA_' => '编辑数据',
	'_EDIT_TITLE_' => '标题：',
	'_EDIT_CONTENT_' => '内容：',
);
