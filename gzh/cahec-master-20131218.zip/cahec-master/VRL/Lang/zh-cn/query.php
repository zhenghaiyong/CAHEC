<?php  
/**
 * CAHEC VRL ISM 简体中文语言包
 * @author   zhenghaiyong <zhenghaiyong@gmail.com>
 */
return array(
    // index.html
	
);
