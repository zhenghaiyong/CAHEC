<?php 
/**
 * CAHEC VRL ISM English language package
 * @author   zhenghaiyong <zhenghaiyong@gmail.com>
 */
return array(
	// index.html
	'_VRL_QUERY_' => 'Virus Sequences Query',
	'_ADVANCED_' => 'More',
	// show.html
	'_VRL_SHOW_' => 'Virus Sequences Results',
);
