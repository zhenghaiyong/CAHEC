<?php 
/**
 * CAHEC VRL ISM English language package
 * @author   zhenghaiyong <zhenghaiyong@gmail.com>
 */
return array(
	// index.html
	'_DATA_LIST_' => 'Data List',
	'_GROUP_NAME_' => 'Group Name',
	'_ID_' => 'ID',
	'_TITLE_' => 'Title',
	'_PUBLISH_TIME_' => 'Publish Time',
	'_STATUS_' => 'Status',
	// add.html
	'_ADD_DATA_' => 'Add Data',
	'_ADD_TITLE_' => 'Title: ',
	'_ADD_CONTENT_' => 'Content: ',
	// edit.html
	'_EDIT_DATA_' => 'Edit Data',
	'_EDIT_TITLE_' => 'Title: ',
	'_EDIT_CONTENT_' => 'Content: ',
);
